# Project-specific ProGuard rules are not needed for this UI prototype.

package com.example.stockroominventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {

    // One screen handles both existing-user authentication and first-time account creation.

    private TextInputLayout usernameLayout;
    private TextInputLayout passwordLayout;
    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);
        usernameLayout = findViewById(R.id.usernameLayout);
        passwordLayout = findViewById(R.id.passwordLayout);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(view -> submitCredentials(false));
        createAccountButton.setOnClickListener(view -> submitCredentials(true));
        passwordInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                submitCredentials(false);
                return true;
            }
            return false;
        });
    }

    // Validate locally first, then let SQLite decide whether account creation/login succeeds.
    private void submitCredentials(boolean creatingAccount) {
        usernameLayout.setError(null);
        passwordLayout.setError(null);

        String username = String.valueOf(usernameInput.getText()).trim();
        String password = String.valueOf(passwordInput.getText());

        if (!validateInput(username, password)) {
            return;
        }

        if (creatingAccount) {
            boolean created = databaseHelper.createUser(username, password);
            if (!created) {
                usernameLayout.setError(getString(R.string.username_taken));
                return;
            }
            openInventory(username, true);
        } else {
            boolean authenticated = databaseHelper.authenticateUser(username, password);
            if (!authenticated) {
                passwordLayout.setError(getString(R.string.invalid_login));
                return;
            }
            openInventory(username, false);
        }
    }

    private boolean validateInput(String username, String password) {
        boolean valid = true;
        if (TextUtils.isEmpty(username)) {
            usernameLayout.setError(getString(R.string.username_required));
            valid = false;
        }
        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError(getString(R.string.password_required));
            valid = false;
        } else if (password.length() < 6) {
            passwordLayout.setError(getString(R.string.password_length));
            valid = false;
        }
        return valid;
    }

    // Authentication is complete before the inventory activity is opened.
    private void openInventory(String username, boolean createdAccount) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra("welcome_name", username);
        intent.putExtra("created_account", createdAccount);
        startActivity(intent);
        finish();
    }
}

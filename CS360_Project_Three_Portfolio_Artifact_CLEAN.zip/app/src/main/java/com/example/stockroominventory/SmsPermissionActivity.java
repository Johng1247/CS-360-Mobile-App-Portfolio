package com.example.stockroominventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class SmsPermissionActivity extends AppCompatActivity {

    // Permission handling is isolated here so denial never blocks login or inventory CRUD features.

    private static final int REQUEST_SEND_SMS = 401;

    private TextView permissionStatusText;
    private TextView permissionExplanationText;
    private MaterialButton allowSmsButton;
    private View permissionGrantedPanel;
    private TextInputLayout phoneNumberLayout;
    private TextInputEditText phoneNumberInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        SmsAlertHelper.preferences(this)
                .edit()
                .putBoolean(SmsAlertHelper.KEY_INTRO_SEEN, true)
                .apply();

        MaterialToolbar toolbar = findViewById(R.id.smsToolbar);
        toolbar.setNavigationOnClickListener(view -> finish());

        permissionStatusText = findViewById(R.id.permissionStatusText);
        permissionExplanationText = findViewById(R.id.permissionExplanationText);
        allowSmsButton = findViewById(R.id.allowSmsButton);
        permissionGrantedPanel = findViewById(R.id.permissionGrantedPanel);
        phoneNumberLayout = findViewById(R.id.phoneNumberLayout);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        MaterialButton savePhoneButton = findViewById(R.id.savePhoneButton);
        MaterialButton sendTestSmsButton = findViewById(R.id.sendTestSmsButton);
        MaterialButton continueButton = findViewById(R.id.continueWithoutSmsButton);

        phoneNumberInput.setText(SmsAlertHelper.getPhoneNumber(this));
        allowSmsButton.setOnClickListener(view -> requestSmsPermissionIfNeeded());
        savePhoneButton.setOnClickListener(view -> savePhoneNumber());
        sendTestSmsButton.setOnClickListener(view -> sendTestMessage());
        continueButton.setOnClickListener(view -> {
            Toast.makeText(this, R.string.app_works_without_sms, Toast.LENGTH_LONG).show();
            finish();
        });

        updatePermissionUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionUi();
    }

    // Ask only for SEND_SMS and show Android's runtime permission dialog when necessary.
    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updatePermissionUi();
            return;
        }

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            permissionExplanationText.setText(R.string.sms_rationale_repeat);
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQUEST_SEND_SMS
        );
    }

    private boolean savePhoneNumber() {
        phoneNumberLayout.setError(null);
        String phoneNumber = String.valueOf(phoneNumberInput.getText()).trim();
        if (TextUtils.isEmpty(phoneNumber)) {
            phoneNumberLayout.setError(getString(R.string.phone_number_required));
            return false;
        }
        SmsAlertHelper.savePhoneNumber(this, phoneNumber);
        Toast.makeText(this, R.string.phone_number_saved, Toast.LENGTH_SHORT).show();
        return true;
    }

    private void sendTestMessage() {
        if (!savePhoneNumber()) {
            return;
        }

        InventoryItem testItem = new InventoryItem(-1, "Test Item", "TEST", 0, "", "");
        boolean sent = SmsAlertHelper.sendZeroStockAlert(this, testItem);
        Toast.makeText(this, sent ? R.string.test_sms_sent : R.string.test_sms_not_sent, Toast.LENGTH_LONG).show();
    }

    // Keep the screen consistent with both device capability and the user's permission decision.
    private void updatePermissionUi() {
        boolean telephonyAvailable = getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY);
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!telephonyAvailable) {
            permissionStatusText.setText(R.string.sms_unavailable);
            permissionExplanationText.setText(R.string.sms_unavailable_explanation);
            allowSmsButton.setVisibility(View.VISIBLE);
            allowSmsButton.setEnabled(false);
            permissionGrantedPanel.setVisibility(View.GONE);
        } else if (granted) {
            permissionStatusText.setText(R.string.sms_enabled);
            permissionExplanationText.setText(R.string.sms_enabled_explanation);
            allowSmsButton.setVisibility(View.GONE);
            permissionGrantedPanel.setVisibility(View.VISIBLE);
        } else {
            permissionStatusText.setText(R.string.sms_not_enabled);
            permissionExplanationText.setText(R.string.sms_permission_explanation);
            allowSmsButton.setVisibility(View.VISIBLE);
            allowSmsButton.setEnabled(true);
            permissionGrantedPanel.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(
                    this,
                    granted ? R.string.sms_permission_granted : R.string.sms_permission_denied,
                    Toast.LENGTH_LONG
            ).show();
            updatePermissionUi();
        }
    }
}

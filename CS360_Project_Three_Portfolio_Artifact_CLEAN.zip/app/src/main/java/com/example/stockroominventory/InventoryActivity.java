package com.example.stockroominventory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemListener {

    // The dashboard always reloads from SQLite so the grid reflects the latest persisted records.

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private TextView totalItemsText;
    private TextView lowStockText;
    private TextView emptyInventoryText;
    private RecyclerView inventoryRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        MaterialToolbar toolbar = findViewById(R.id.inventoryToolbar);
        setSupportActionBar(toolbar);

        String welcomeName = getIntent().getStringExtra("welcome_name");
        TextView greetingText = findViewById(R.id.greetingText);
        greetingText.setText(getString(R.string.welcome_user, welcomeName == null ? "team member" : welcomeName));

        totalItemsText = findViewById(R.id.totalItemsText);
        lowStockText = findViewById(R.id.lowStockText);
        emptyInventoryText = findViewById(R.id.emptyInventoryText);
        inventoryRecycler = findViewById(R.id.inventoryRecycler);
        ExtendedFloatingActionButton addItemButton = findViewById(R.id.addItemButton);

        adapter = new InventoryAdapter(this);
        inventoryRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        inventoryRecycler.setAdapter(adapter);

        addItemButton.setOnClickListener(view -> startActivity(new Intent(this, ItemFormActivity.class)));

        if (getIntent().getBooleanExtra("created_account", false)) {
            Snackbar.make(inventoryRecycler, R.string.account_created_message, Snackbar.LENGTH_LONG).show();
        }

        showSmsIntroductionIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    // READ operation: query every inventory row and display the result in a two-column grid.
    private void loadInventory() {
        List<InventoryItem> items = databaseHelper.getAllInventoryItems();
        adapter.replaceItems(items);

        totalItemsText.setText(String.valueOf(items.size()));
        int needsAttention = 0;
        for (InventoryItem item : items) {
            if (item.getQuantity() <= 5) {
                needsAttention++;
            }
        }
        lowStockText.setText(String.valueOf(needsAttention));
        emptyInventoryText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        inventoryRecycler.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    // SMS is optional; introduce the feature without blocking the core inventory workflow.
    private void showSmsIntroductionIfNeeded() {
        boolean alreadySeen = SmsAlertHelper.preferences(this)
                .getBoolean(SmsAlertHelper.KEY_INTRO_SEEN, false);
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (alreadySeen || permissionGranted) {
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.sms_optional_title)
                .setMessage(R.string.sms_optional_message)
                .setNegativeButton(R.string.not_now, (dialog, which) ->
                        SmsAlertHelper.preferences(this).edit()
                                .putBoolean(SmsAlertHelper.KEY_INTRO_SEEN, true)
                                .apply())
                .setPositiveButton(R.string.configure_sms, (dialog, which) ->
                        startActivity(new Intent(this, SmsPermissionActivity.class)))
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_sms) {
            startActivity(new Intent(this, SmsPermissionActivity.class));
            return true;
        }
        if (item.getItemId() == R.id.action_logout) {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemSelected(InventoryItem item) {
        Intent intent = new Intent(this, ItemDetailActivity.class);
        intent.putExtra(ItemDetailActivity.EXTRA_ITEM_ID, item.getId());
        startActivity(intent);
    }

    @Override
    // DELETE operation is confirmed before the selected database row is removed.
    public void onDeleteSelected(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_item)
                .setMessage(getString(R.string.delete_confirmation, item.getName()))
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    if (databaseHelper.deleteInventoryItem(item.getId())) {
                        loadInventory();
                        Snackbar.make(findViewById(R.id.inventoryRoot), R.string.item_deleted, Snackbar.LENGTH_LONG).show();
                    }
                })
                .show();
    }
}

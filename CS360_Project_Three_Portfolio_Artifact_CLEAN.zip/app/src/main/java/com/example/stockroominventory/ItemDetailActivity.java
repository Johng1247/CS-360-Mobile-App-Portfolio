package com.example.stockroominventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

public class ItemDetailActivity extends AppCompatActivity {

    // Item details are re-read on resume so edits made on another screen are shown immediately.

    public static final String EXTRA_ITEM_ID = "item_id";

    private DatabaseHelper databaseHelper;
    private long itemId;
    private InventoryItem currentItem;
    private TextView itemNameText;
    private TextView skuText;
    private TextView quantityText;
    private TextView statusText;
    private View lowStockBanner;
    private MaterialButton minusButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        databaseHelper = new DatabaseHelper(this);
        itemId = getIntent().getLongExtra(EXTRA_ITEM_ID, -1);

        MaterialToolbar toolbar = findViewById(R.id.itemDetailToolbar);
        toolbar.setNavigationOnClickListener(view -> finish());

        itemNameText = findViewById(R.id.detailItemName);
        skuText = findViewById(R.id.detailSku);
        quantityText = findViewById(R.id.detailQuantity);
        statusText = findViewById(R.id.detailStatus);
        lowStockBanner = findViewById(R.id.lowStockBanner);
        minusButton = findViewById(R.id.minusQuantityButton);
        MaterialButton plusButton = findViewById(R.id.plusQuantityButton);
        MaterialButton editButton = findViewById(R.id.editItemButton);
        MaterialButton deleteButton = findViewById(R.id.deleteItemButton);

        minusButton.setOnClickListener(view -> changeQuantity(-1));
        plusButton.setOnClickListener(view -> changeQuantity(1));
        editButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, ItemFormActivity.class);
            intent.putExtra(ItemFormActivity.EXTRA_ITEM_ID, itemId);
            startActivity(intent);
        });
        deleteButton.setOnClickListener(view -> confirmDelete());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItem();
    }

    private void loadItem() {
        currentItem = databaseHelper.getInventoryItem(itemId);
        if (currentItem == null) {
            Toast.makeText(this, R.string.item_not_found, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        itemNameText.setText(currentItem.getName());
        skuText.setText(getString(
                R.string.sku_value,
                TextUtils.isEmpty(currentItem.getSku()) ? getString(R.string.not_assigned) : currentItem.getSku()
        ));
        refreshQuantityState();
    }

    // Quantity updates persist immediately and never allow a value below zero.
    private void changeQuantity(int difference) {
        if (currentItem == null) {
            return;
        }

        int previousQuantity = currentItem.getQuantity();
        int updatedQuantity = Math.max(0, previousQuantity + difference);
        if (updatedQuantity == previousQuantity) {
            return;
        }

        if (databaseHelper.updateQuantity(itemId, updatedQuantity)) {
            currentItem.setQuantity(updatedQuantity);
            refreshQuantityState();

            // A transition from positive stock to zero is the Inventory App SMS trigger.
            if (previousQuantity > 0 && updatedQuantity == 0) {
                boolean sent = SmsAlertHelper.sendZeroStockAlert(this, currentItem);
                Toast.makeText(
                        this,
                        sent ? R.string.zero_stock_sms_sent : R.string.zero_stock_sms_not_sent,
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private void refreshQuantityState() {
        quantityText.setText(String.valueOf(currentItem.getQuantity()));
        minusButton.setEnabled(currentItem.getQuantity() > 0);

        if (currentItem.isOutOfStock()) {
            statusText.setText(R.string.out_of_stock);
            lowStockBanner.setVisibility(View.VISIBLE);
        } else if (currentItem.isLowStock()) {
            statusText.setText(R.string.low_stock);
            lowStockBanner.setVisibility(View.VISIBLE);
        } else {
            statusText.setText(R.string.in_stock);
            lowStockBanner.setVisibility(View.GONE);
        }
    }

    private void confirmDelete() {
        if (currentItem == null) {
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_item)
                .setMessage(getString(R.string.delete_confirmation, currentItem.getName()))
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    if (databaseHelper.deleteInventoryItem(itemId)) {
                        Toast.makeText(this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .show();
    }
}

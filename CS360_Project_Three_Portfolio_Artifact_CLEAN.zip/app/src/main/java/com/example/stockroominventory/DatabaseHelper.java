package com.example.stockroominventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "stockroom.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory_items";

    private static final int PASSWORD_ITERATIONS = 65536;
    private static final int PASSWORD_KEY_LENGTH = 256;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // User credentials are stored separately from inventory records and are never shown in the grid.
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                "password_hash TEXT NOT NULL, " +
                "password_salt TEXT NOT NULL)");

        // This table begins empty so each user can populate the persistent inventory database later.
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "sku TEXT, " +
                "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0), " +
                "location TEXT, " +
                "notes TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No schema migration is required for version 1. Future versions can migrate data here.
    }

    public boolean createUser(String username, String password) {
        if (usernameExists(username)) {
            return false;
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String encodedSalt = Base64.encodeToString(salt, Base64.NO_WRAP);
        String passwordHash = hashPassword(password, salt);
        if (passwordHash == null) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", passwordHash);
        values.put("password_salt", encodedSalt);

        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    public boolean authenticateUser(String username, String password) {
        Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"password_hash", "password_salt"},
                "username = ? COLLATE NOCASE",
                new String[]{username.trim()},
                null,
                null,
                null
        );

        try {
            if (!cursor.moveToFirst()) {
                return false;
            }
            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            byte[] salt = Base64.decode(cursor.getString(cursor.getColumnIndexOrThrow("password_salt")), Base64.NO_WRAP);
            String attemptedHash = hashPassword(password, salt);
            return attemptedHash != null && storedHash.equals(attemptedHash);
        } finally {
            cursor.close();
        }
    }

    private boolean usernameExists(String username) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT 1 FROM " + TABLE_USERS + " WHERE username = ? COLLATE NOCASE LIMIT 1",
                new String[]{username.trim()}
        );
        try {
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }

    private String hashPassword(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PASSWORD_ITERATIONS, PASSWORD_KEY_LENGTH);
        try {
            // PBKDF2 avoids storing a readable password in the local SQLite database.
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] encoded = factory.generateSecret(spec).getEncoded();
            return Base64.encodeToString(encoded, Base64.NO_WRAP);
        } catch (Exception exception) {
            return null;
        } finally {
            spec.clearPassword();
        }
    }

    public long insertInventoryItem(String name, String sku, int quantity, String location, String notes) {
        ContentValues values = inventoryValues(name, sku, quantity, location, notes);
        return getWritableDatabase().insert(TABLE_INVENTORY, null, values);
    }

    public boolean updateInventoryItem(long id, String name, String sku, int quantity, String location, String notes) {
        ContentValues values = inventoryValues(name, sku, quantity, location, notes);
        int rows = getWritableDatabase().update(TABLE_INVENTORY, values, "_id = ?", new String[]{String.valueOf(id)});
        return rows == 1;
    }

    public boolean updateQuantity(long id, int quantity) {
        ContentValues values = new ContentValues();
        values.put("quantity", Math.max(0, quantity));
        int rows = getWritableDatabase().update(TABLE_INVENTORY, values, "_id = ?", new String[]{String.valueOf(id)});
        return rows == 1;
    }

    public boolean deleteInventoryItem(long id) {
        int rows = getWritableDatabase().delete(TABLE_INVENTORY, "_id = ?", new String[]{String.valueOf(id)});
        return rows == 1;
    }

    public InventoryItem getInventoryItem(long id) {
        Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                null,
                "_id = ?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
        try {
            return cursor.moveToFirst() ? itemFromCursor(cursor) : null;
        } finally {
            cursor.close();
        }
    }

    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                "name COLLATE NOCASE ASC"
        );
        try {
            while (cursor.moveToNext()) {
                items.add(itemFromCursor(cursor));
            }
        } finally {
            cursor.close();
        }
        return items;
    }

    private ContentValues inventoryValues(String name, String sku, int quantity, String location, String notes) {
        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("sku", sku == null ? "" : sku.trim());
        values.put("quantity", Math.max(0, quantity));
        values.put("location", location == null ? "" : location.trim());
        values.put("notes", notes == null ? "" : notes.trim());
        return values;
    }

    private InventoryItem itemFromCursor(Cursor cursor) {
        return new InventoryItem(
                cursor.getLong(cursor.getColumnIndexOrThrow("_id")),
                cursor.getString(cursor.getColumnIndexOrThrow("name")),
                cursor.getString(cursor.getColumnIndexOrThrow("sku")),
                cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                cursor.getString(cursor.getColumnIndexOrThrow("location")),
                cursor.getString(cursor.getColumnIndexOrThrow("notes"))
        );
    }
}

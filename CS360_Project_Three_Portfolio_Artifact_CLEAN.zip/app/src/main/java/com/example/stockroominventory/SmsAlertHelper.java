package com.example.stockroominventory;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public final class SmsAlertHelper {

    // Centralizes optional SMS settings and the guarded send operation used by inventory screens.

    public static final String PREFS_NAME = "sms_settings";
    public static final String KEY_PHONE_NUMBER = "alert_phone_number";
    public static final String KEY_INTRO_SEEN = "sms_intro_seen";

    private SmsAlertHelper() {
    }

    public static void savePhoneNumber(Context context, String phoneNumber) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_PHONE_NUMBER, phoneNumber.trim())
                .apply();
    }

    public static String getPhoneNumber(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_PHONE_NUMBER, "");
    }

    // Return false instead of throwing when permission, telephony, or an alert number is unavailable.
    public static boolean sendZeroStockAlert(Context context, InventoryItem item) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        if (!context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) {
            return false;
        }

        String phoneNumber = getPhoneNumber(context).trim();
        if (phoneNumber.isEmpty()) {
            return false;
        }

        String message = "StockRoom alert: " + item.getName() + " has reached zero in inventory.";
        try {
            // SmsManager is called only after the runtime SEND_SMS permission has been granted.
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    public static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}

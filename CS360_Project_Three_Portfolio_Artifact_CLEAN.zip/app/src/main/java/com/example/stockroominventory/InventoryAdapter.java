package com.example.stockroominventory;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // RecyclerView keeps database records separate from the code that renders each grid card.

    public interface ItemListener {
        void onItemSelected(InventoryItem item);
        void onDeleteSelected(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final ItemListener listener;

    public InventoryAdapter(ItemListener listener) {
        this.listener = listener;
    }

    // Replace the visible snapshot after each database read instead of maintaining duplicate state.
    public void replaceItems(List<InventoryItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_card, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.name.setText(item.getName());
        holder.sku.setText(TextUtils.isEmpty(item.getSku()) ? holder.itemView.getContext().getString(R.string.no_sku) : item.getSku());
        holder.quantity.setText(String.valueOf(item.getQuantity()));

        if (item.isOutOfStock()) {
            holder.status.setText(R.string.out_of_stock);
            holder.status.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_warning, 0, 0, 0);
            holder.card.setStrokeColor(holder.itemView.getContext().getColor(R.color.status_danger));
        } else if (item.isLowStock()) {
            holder.status.setText(R.string.low_stock);
            holder.status.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_warning, 0, 0, 0);
            holder.card.setStrokeColor(holder.itemView.getContext().getColor(R.color.status_warning));
        } else {
            holder.status.setText(R.string.in_stock);
            holder.status.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_check, 0, 0, 0);
            holder.card.setStrokeColor(holder.itemView.getContext().getColor(R.color.status_good));
        }

        holder.card.setOnClickListener(view -> listener.onItemSelected(item));
        holder.deleteButton.setOnClickListener(view -> listener.onDeleteSelected(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final TextView name;
        final TextView sku;
        final TextView quantity;
        final TextView status;
        final MaterialButton deleteButton;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.inventoryCard);
            name = itemView.findViewById(R.id.itemNameText);
            sku = itemView.findViewById(R.id.skuText);
            quantity = itemView.findViewById(R.id.quantityText);
            status = itemView.findViewById(R.id.statusText);
            deleteButton = itemView.findViewById(R.id.deleteRowButton);
        }
    }
}

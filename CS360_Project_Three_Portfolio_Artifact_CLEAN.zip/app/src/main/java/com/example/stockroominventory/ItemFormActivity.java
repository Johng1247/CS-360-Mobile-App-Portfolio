package com.example.stockroominventory;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ItemFormActivity extends AppCompatActivity {

    // The same form performs CREATE for new records and UPDATE when an item ID is supplied.

    public static final String EXTRA_ITEM_ID = "item_id";

    private DatabaseHelper databaseHelper;
    private TextInputLayout nameLayout;
    private TextInputLayout quantityLayout;
    private TextInputEditText nameInput;
    private TextInputEditText skuInput;
    private TextInputEditText quantityInput;
    private TextInputEditText locationInput;
    private TextInputEditText notesInput;
    private long itemId = -1;
    private int originalQuantity = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_form);

        databaseHelper = new DatabaseHelper(this);
        itemId = getIntent().getLongExtra(EXTRA_ITEM_ID, -1);

        MaterialToolbar toolbar = findViewById(R.id.itemFormToolbar);
        toolbar.setNavigationOnClickListener(view -> finish());

        nameLayout = findViewById(R.id.itemNameLayout);
        quantityLayout = findViewById(R.id.itemQuantityLayout);
        nameInput = findViewById(R.id.itemNameInput);
        skuInput = findViewById(R.id.itemSkuInput);
        quantityInput = findViewById(R.id.itemQuantityInput);
        locationInput = findViewById(R.id.itemLocationInput);
        notesInput = findViewById(R.id.itemNotesInput);
        Button saveButton = findViewById(R.id.saveItemButton);
        Button cancelButton = findViewById(R.id.cancelItemButton);

        if (itemId != -1) {
            toolbar.setTitle(R.string.edit_inventory_item);
            loadItemForEditing();
        }

        cancelButton.setOnClickListener(view -> finish());
        saveButton.setOnClickListener(view -> saveItem());
    }

    private void loadItemForEditing() {
        InventoryItem item = databaseHelper.getInventoryItem(itemId);
        if (item == null) {
            Toast.makeText(this, R.string.item_not_found, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        originalQuantity = item.getQuantity();
        nameInput.setText(item.getName());
        skuInput.setText(item.getSku());
        quantityInput.setText(String.valueOf(item.getQuantity()));
        locationInput.setText(item.getLocation());
        notesInput.setText(item.getNotes());
    }

    // Reject incomplete or invalid quantities before writing anything to SQLite.
    private void saveItem() {
        nameLayout.setError(null);
        quantityLayout.setError(null);

        String name = String.valueOf(nameInput.getText()).trim();
        String sku = String.valueOf(skuInput.getText()).trim();
        String quantityText = String.valueOf(quantityInput.getText()).trim();
        String location = String.valueOf(locationInput.getText()).trim();
        String notes = String.valueOf(notesInput.getText()).trim();

        if (TextUtils.isEmpty(name)) {
            nameLayout.setError(getString(R.string.item_name_required));
            return;
        }
        if (TextUtils.isEmpty(quantityText)) {
            quantityLayout.setError(getString(R.string.quantity_required));
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
            if (quantity < 0) {
                quantityLayout.setError(getString(R.string.quantity_nonnegative));
                return;
            }
        } catch (NumberFormatException exception) {
            quantityLayout.setError(getString(R.string.quantity_whole_number));
            return;
        }

        // Choose the appropriate CRUD operation based on whether this is a new or existing item.
        boolean success;
        long savedItemId = itemId;
        if (itemId == -1) {
            savedItemId = databaseHelper.insertInventoryItem(name, sku, quantity, location, notes);
            success = savedItemId != -1;
        } else {
            success = databaseHelper.updateInventoryItem(itemId, name, sku, quantity, location, notes);
        }

        if (!success) {
            Toast.makeText(this, R.string.save_failed, Toast.LENGTH_LONG).show();
            return;
        }

        InventoryItem savedItem = databaseHelper.getInventoryItem(savedItemId);
        boolean reachedZero = quantity == 0 && (itemId == -1 || originalQuantity > 0);
        if (reachedZero && savedItem != null) {
            SmsAlertHelper.sendZeroStockAlert(this, savedItem);
        }

        Toast.makeText(this, itemId == -1 ? R.string.item_saved : R.string.item_updated, Toast.LENGTH_SHORT).show();
        finish();
    }
}

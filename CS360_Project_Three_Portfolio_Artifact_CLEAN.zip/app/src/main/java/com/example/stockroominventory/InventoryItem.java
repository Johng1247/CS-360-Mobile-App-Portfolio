package com.example.stockroominventory;

public class InventoryItem {

    // Plain model object used to move one SQLite inventory row between the database and UI.
    private final long id;
    private final String name;
    private final String sku;
    private int quantity;
    private final String location;
    private final String notes;

    public InventoryItem(long id, String name, String sku, int quantity, String location, String notes) {
        this.id = id;
        this.name = name;
        this.sku = sku == null ? "" : sku;
        this.quantity = Math.max(0, quantity);
        this.location = location == null ? "" : location;
        this.notes = notes == null ? "" : notes;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = Math.max(0, quantity);
    }

    public String getLocation() {
        return location;
    }

    public String getNotes() {
        return notes;
    }

    public boolean isOutOfStock() {
        return quantity == 0;
    }

    public boolean isLowStock() {
        return quantity > 0 && quantity <= 5;
    }
}
